(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/georun-project/georun-fe/components/RouteMap.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/0nae_0kwpw1p._.js",
  "static/chunks/Desktop_georun-project_georun-fe_components_RouteMap_tsx_0dqu8i4._.js",
  "static/chunks/Desktop_georun-project_georun-fe_components_RouteMap_tsx_1xjyg1k._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/georun-project/georun-fe/components/RouteMap.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);