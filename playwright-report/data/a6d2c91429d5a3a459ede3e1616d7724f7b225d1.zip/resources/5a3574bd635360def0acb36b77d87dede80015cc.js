(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0ntwfw5._.js","static/chunks/0nae_next_dist_compiled_next-devtools_index_0bn4w2y.js","static/chunks/0nae_next_dist_compiled_react-dom_09m1hnp._.js","static/chunks/0nae_next_dist_compiled_react-server-dom-turbopack_1aby07x._.js","static/chunks/0nae_next_dist_compiled_19qr44c._.js","static/chunks/0nae_next_dist_client_0sl_295._.js","static/chunks/0nae_next_dist_1-prsor._.js","static/chunks/0nae_@swc_helpers_cjs_0zrh0ec._.js"],
    source: "entry"
});
