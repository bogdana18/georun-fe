(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0h2i44o._.css","static/chunks/0nae_next_dist_0s1q39p._.js"],
    source: "dynamic"
});
